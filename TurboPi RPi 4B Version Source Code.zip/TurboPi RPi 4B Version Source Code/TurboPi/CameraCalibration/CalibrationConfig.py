#标定棋盘大小, 列, 行, 指内角点个数，非棋盘格
calibration_size = (8, 6)

#采集标定图像存储路径
save_path = '/home/pi/TurboPi/CameraCalibration/calibration_images/'

#标定参数存储路径
calibration_param_path = '/home/pi/TurboPi/CameraCalibration/calibration_param'
